<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $inquiry_type = $_POST['inquiry_type'];
    $message = $_POST['message'];

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'deenis@deenislawchamberandservices.com'; // Replace with your email
        $mail->Password = 'Deenis@2024'; // Replace with your email password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 465;

        // Alternative port configuration
        // $mail->Port = 465;
        // $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;

        $mail->setFrom('deepakdahiya021@gmail.com', 'Deenis Law Chamber'); // Replace with your email
        $mail->addAddress('Deenis.group2000@gmail.com', 'Deenis Law Chamber') ;

        $mail->isHTML(true);
        $mail->Subject = 'New Inquiry from ' . $full_name;
        $mail->Body = "Name: $full_name<br>Email: $email<br>Phone: $phone_number<br>Inquiry Type: $inquiry_type<br>Message: $message";

        $mail->SMTPDebug = 3; // Enable verbose debug output
        $mail->Debugoutput = function($str, $level) {
            echo "Debug level $level; message: $str\n";
        };
        

        $mail->send();
        echo "Message has been sent successfully.";
    } catch (Exception $e) {
        error_log("Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
        echo "Message could not be sent. Please try again later.";
    }
} else {
    echo "No POST request received.";
}
?>